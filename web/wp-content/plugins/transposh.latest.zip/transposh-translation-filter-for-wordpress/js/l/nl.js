/*
 * Transposh v0.9.7.0
 * http://transposh.org/
 *
 * Copyright 2015, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Fri, 05 Jun 2015 02:32:15 +0300
 */
t_jp.l={"Close without saving?":"Sluiten zonder op te slaan?","You have made a change to the translation. Are you sure you want to discard it?":"Je hebt de vertaling aangepast. Weet je zeker dat je dat wilt annuleren?",History:"Geschiedenis","Loading...":"Aan het laden...",Translated:"Vertaald",By:"Door",At:"Op",google:"google",bing:"bing",apertium:"apertium","manual translation":"eigen vertaling","bing suggest":"bing suggestie","google suggest":"google suggestie","apertium suggest":"apertium suggestie",
"Edit Translation":"Vertaling aanpassen","Original text":"Oorspronkelijke tekst","read alternate translations":"bekijk alternatieve vertaling","previous translation":"vorige","find on page":"laat op de pagina zien","next translation":"volgende","Translate to":"Vertaal naar","view translation log":"Bekijk vertaallog","virtual keyboard":"virtueel toetsenbord","approve translation":"vertaling goedkeuren","delete":"verwijder",Discard:"weggooien",Cancel:"Annuleren"};
