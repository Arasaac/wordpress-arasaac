/*
 * Transposh v0.9.7.0
 * http://transposh.org/
 *
 * Copyright 2015, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Fri, 05 Jun 2015 02:32:15 +0300
 */
t_jp.l={"Close without saving?":"Schlie\u00dfen ohne Speichern?","You have made a change to the translation. Are you sure you want to discard it?":"Sie haben die \u00dcbersetzung bearbeitet. Sind Sie sicher, dass Sie abbrechen wollen?",History:"Verlauf","Loading...":"Laden...",Translated:"\u00dcbersetzt",By:"von",At:"\u00fcber",google:"Google",bing:"Bing",apertium:"Apertium","manual translation":"manuelle \u00dcbersetzung","bing suggest":"Bing Suggest","google suggest":"Google Suggest","apertium suggest":"Apertium Suggest",
"Edit Translation":"\u00dcbersetzung bearbeiten","Original text":"Originaltext","read alternate translations":"alternative \u00dcbersetzung lesen","previous translation":"Vorherige","find on page":"Auf Seite suchen","next translation":"N\u00e4chste","Translate to":"\u00dcbersetzen nach","view translation log":"\u00dcbersetzungsprotokoll anzeigen","virtual keyboard":"virtuelle Tastatur","approve translation":"\u00dcbersetzung genehmigen","delete":"L\u00f6schen",Discard:"Verwerfen",Cancel:"Abbrechen"};
